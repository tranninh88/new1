const e="FuelWeb3",s="FuelWeb3ContentScript",t="FuelWeb3BackgroundScript",E="FuelWeb3PopUpScript",P="message";export{t as B,s as C,P as E,E as P,e as a};
